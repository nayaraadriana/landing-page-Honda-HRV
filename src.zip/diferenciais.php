<div class="container-diferenciais">
   
   
    <div>
        <img class="" src="/imagens/diferenciais/direcao-eletrica-progressiva.jpg" alt="visao interna do carro">
    </div>

    <div class="box-chamada-diferenciais">
        
        <h2 class="title-padrao__diferenciais">Direção Elétrica progressiva com sistema EPS</h2>
        <p class="texto-padrao__diferenciais">O EPS faz com que a direção fique mais rígida em velocidades maiores, deixando a condução mais segura, e macia em velocidade menores para facilitar manobras, garantindo maior controle e segurança ao dirigir.</p>
        
        <button class=" btn-cotacao btn-cotacao__diferenciais">
            Tenho interesse
        </button>

    </div>

</div>