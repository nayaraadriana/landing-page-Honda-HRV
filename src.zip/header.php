<header>
    <div class="container">

        <div class="topo">
           
            <h1 class="logo">
                <img class="logo__img"src="/imagens/logotipos/logo-kaizen.PNG" alt="logo-kaisen-honda">    
            </h1>

            
            <button class="btn-cotacao">
                Cotação
            </button>
            
                
            <div class="box-info-contato">
                <div class="box-info-contato__item">
                    <p class="box-info-contato__nome">Kaizen RS</p>
                    <p class="box-info-contato__telefone">(051) 2125-1602</p>
                </div>    
        
                <div class="box-info-contato__item">
                    <p class="box-info-contato__nome">Kaizen RS Zona Sul</p>
                    <p class="box-info-contato__telefone">(051) 2125-1603</p>
                </div>
            </div>
        </div>
    </div>
</header>