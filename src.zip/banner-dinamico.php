<div class="container">
    
    <div class="box-chamada">

        <div class="box-chamada__dinamico">
            
            <h2 class="title-padrao__banner">Design Dinâmico</h2>
            
            <p class= "box-texto__banner">Design aerodinâmico, com vincos marcantes, dá ao Honda HR-V esportividade e jovialidade, diferenciando-o de outros SUVs. Beleza, imponência e sofisticação são marcas do design inovador by Honda.</p>

            <button class="btn-cotacao">Cotação</button>

        </div>

    </div>   



    <div class="box-dinanimico__img">       
        <img class="banner-dinamico__img" src="/imagens/banners/banner-dinamico.jpg">
    </div>

</div>