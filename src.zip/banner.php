<div class="banner-principal">
    <picture >
        <source media="(min-width: 800px)" srcset="/imagens/banners/banner-desktop.jpg">    
        <source srcset="/imagens/banners/banner-mobile.jpg">
        <img class="banner-principal__img" src="/imagens/banners/banner-desktop.jpg" alt="banner-principal">
    </picture>
</div>