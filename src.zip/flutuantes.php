<ul class="box-flutuante">
        <li>
          <picture>
						<source media="(min-width: 900px)" srcset="/imagens/icones/arrow-up.png" alt="seta para cima">
						<source srcset="/imagens/icones/comments.png">
						<img src="/imagens/icones/comments.png" alt="icone-cotacao">
					</picture>
					<p>Solicite uma cotação</p>
				</li>

				<li>
					<picture>
					<source src="/imagens/icones/whatsapp.png">
					</picture>
					<p>Whatsapp</p>
				</li>
</ul>